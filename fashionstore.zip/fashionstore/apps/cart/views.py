from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib import messages
from .cart import Cart
from apps.store.models import ProductVariant


def cart_detail(request):
    cart = Cart(request)
    return render(request, 'cart/cart.html', {'cart': cart})


@require_POST
def add_to_cart(request, variant_id):
    cart = Cart(request)
    variant = get_object_or_404(ProductVariant, id=variant_id)
    quantity = int(request.POST.get('quantity', 1))
    
    if variant.stock < quantity:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'message': 'موجودی کافی نیست.'})
        messages.error(request, 'موجودی کافی نیست.')
        return redirect(request.META.get('HTTP_REFERER', '/'))
    
    cart.add(variant, quantity)
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_count': len(cart),
            'message': 'محصول به سبد خرید اضافه شد.'
        })
    messages.success(request, 'محصول به سبد خرید اضافه شد.')
    return redirect('cart:detail')


@require_POST
def remove_from_cart(request, variant_id):
    cart = Cart(request)
    variant = get_object_or_404(ProductVariant, id=variant_id)
    cart.remove(variant)
    return redirect('cart:detail')


@require_POST
def update_cart(request, variant_id):
    cart = Cart(request)
    variant = get_object_or_404(ProductVariant, id=variant_id)
    quantity = int(request.POST.get('quantity', 1))
    
    if quantity <= 0:
        cart.remove(variant)
    else:
        cart.add(variant, quantity, override_quantity=True)
    
    return redirect('cart:detail')


def cart_count(request):
    cart = Cart(request)
    return JsonResponse({'count': len(cart)})
