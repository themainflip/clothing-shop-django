from django.urls import path
from . import views

app_name = 'cart'

urlpatterns = [
    path('', views.cart_detail, name='detail'),
    path('add/<int:variant_id>/', views.add_to_cart, name='add'),
    path('remove/<int:variant_id>/', views.remove_from_cart, name='remove'),
    path('update/<int:variant_id>/', views.update_cart, name='update'),
    path('count/', views.cart_count, name='count'),
]
