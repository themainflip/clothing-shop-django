from django.urls import path
from . import views

app_name = 'orders'

urlpatterns = [
    path('checkout/', views.checkout, name='checkout'),
    path('payment/<uuid:order_id>/', views.payment, name='payment'),
    path('confirm/<uuid:order_id>/', views.order_confirm, name='order_confirm'),
    path('my-orders/', views.order_list, name='order_list'),
    path('my-orders/<uuid:order_id>/', views.order_detail, name='order_detail'),
    path('return/<int:order_item_id>/', views.return_request, name='return_request'),
    path('apply-coupon/', views.apply_coupon, name='apply_coupon'),
]
