from django.contrib import admin
from .models import Order, OrderItem, Payment, Coupon, ReturnRequest


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['total_price']


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'user', 'status', 'total', 'payment_method', 'created_at']
    list_filter = ['status', 'payment_method', 'shipping_method']
    search_fields = ['order_number', 'user__username']
    readonly_fields = ['order_number', 'created_at']
    inlines = [OrderItemInline]
    list_editable = ['status']


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ['code', 'coupon_type', 'value', 'usage_count', 'is_active', 'valid_from', 'valid_to']
    list_editable = ['is_active']


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['order', 'amount', 'gateway', 'status', 'ref_id', 'created_at']
    list_filter = ['status', 'gateway']
    readonly_fields = ['created_at']


@admin.register(ReturnRequest)
class ReturnRequestAdmin(admin.ModelAdmin):
    list_display = ['order_item', 'user', 'reason', 'status', 'created_at']
    list_filter = ['status', 'reason']
    list_editable = ['status']
