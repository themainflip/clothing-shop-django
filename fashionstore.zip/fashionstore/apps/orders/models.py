from django.db import models
from django.contrib.auth import get_user_model
import uuid

User = get_user_model()


class Coupon(models.Model):
    TYPE_CHOICES = [
        ('percent', 'درصدی'),
        ('fixed', 'مبلغ ثابت'),
        ('shipping', 'ارسال رایگان'),
    ]
    code = models.CharField('کد تخفیف', max_length=50, unique=True)
    coupon_type = models.CharField('نوع', max_length=10, choices=TYPE_CHOICES, default='percent')
    value = models.DecimalField('مقدار', max_digits=10, decimal_places=0)
    min_purchase = models.DecimalField('حداقل خرید', max_digits=12, decimal_places=0, default=0)
    max_discount = models.DecimalField('حداکثر تخفیف', max_digits=12, decimal_places=0, null=True, blank=True)
    usage_limit = models.PositiveIntegerField('حداکثر استفاده', null=True, blank=True)
    usage_count = models.PositiveIntegerField('تعداد استفاده', default=0)
    per_user_limit = models.PositiveIntegerField('حداکثر استفاده هر کاربر', default=1)
    is_active = models.BooleanField('فعال', default=True)
    valid_from = models.DateTimeField('از تاریخ')
    valid_to = models.DateTimeField('تا تاریخ')
    is_for_first_purchase = models.BooleanField('فقط اولین خرید', default=False)
    is_for_students = models.BooleanField('فقط دانشجویان', default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'کد تخفیف'
        verbose_name_plural = 'کدهای تخفیف'

    def __str__(self):
        return self.code

    def calculate_discount(self, amount):
        if self.coupon_type == 'percent':
            discount = amount * self.value / 100
            if self.max_discount:
                discount = min(discount, self.max_discount)
        elif self.coupon_type == 'fixed':
            discount = self.value
        else:
            discount = 0  # shipping handled separately
        return discount


class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار پرداخت'),
        ('paid', 'پرداخت شده'),
        ('processing', 'در حال پردازش'),
        ('shipped', 'ارسال شده'),
        ('delivered', 'تحویل داده شده'),
        ('cancelled', 'لغو شده'),
        ('refunded', 'مسترد شده'),
    ]
    SHIPPING_METHOD_CHOICES = [
        ('express', 'اکسپرس'),
        ('standard', 'پستی'),
        ('tipax', 'تیپاکس'),
        ('pickup', 'تحویل حضوری'),
    ]
    PAYMENT_METHOD_CHOICES = [
        ('online', 'آنلاین'),
        ('cod', 'پرداخت در محل'),
        ('installment', 'اقساطی'),
        ('wallet', 'کیف پول'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_number = models.CharField('شماره سفارش', max_length=20, unique=True)
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name='orders')
    
    # Address
    shipping_address = models.TextField('آدرس ارسال')
    receiver_name = models.CharField('نام تحویل‌گیرنده', max_length=200)
    receiver_phone = models.CharField('شماره تحویل‌گیرنده', max_length=11)
    
    # Pricing
    subtotal = models.DecimalField('جمع کالاها', max_digits=12, decimal_places=0)
    shipping_cost = models.DecimalField('هزینه ارسال', max_digits=10, decimal_places=0, default=0)
    discount_amount = models.DecimalField('مبلغ تخفیف', max_digits=12, decimal_places=0, default=0)
    tax_amount = models.DecimalField('مالیات', max_digits=12, decimal_places=0, default=0)
    total = models.DecimalField('مبلغ کل', max_digits=12, decimal_places=0)
    
    coupon = models.ForeignKey(Coupon, on_delete=models.SET_NULL, null=True, blank=True)
    loyalty_points_used = models.PositiveIntegerField('امتیاز استفاده‌شده', default=0)
    wallet_amount_used = models.DecimalField('موجودی کیف پول استفاده‌شده', max_digits=12, decimal_places=0, default=0)
    
    status = models.CharField('وضعیت', max_length=20, choices=STATUS_CHOICES, default='pending')
    shipping_method = models.CharField('روش ارسال', max_length=20, choices=SHIPPING_METHOD_CHOICES)
    payment_method = models.CharField('روش پرداخت', max_length=20, choices=PAYMENT_METHOD_CHOICES)
    
    # Gift
    is_gift = models.BooleanField('بسته هدیه', default=False)
    gift_message = models.TextField('پیام هدیه', blank=True)
    has_insurance = models.BooleanField('بیمه مرسوله', default=False)
    
    # Tracking
    tracking_code = models.CharField('کد رهگیری', max_length=100, blank=True)
    estimated_delivery = models.DateField('تاریخ تحویل تخمینی', null=True, blank=True)
    delivered_at = models.DateTimeField('تاریخ تحویل', null=True, blank=True)
    
    notes = models.TextField('یادداشت', blank=True)
    
    created_at = models.DateTimeField('تاریخ ثبت', auto_now_add=True)
    updated_at = models.DateTimeField('آخرین ویرایش', auto_now=True)

    class Meta:
        verbose_name = 'سفارش'
        verbose_name_plural = 'سفارشات'
        ordering = ['-created_at']

    def __str__(self):
        return self.order_number

    def save(self, *args, **kwargs):
        if not self.order_number:
            import random
            self.order_number = f"FS{random.randint(10000000, 99999999)}"
        super().save(*args, **kwargs)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey('store.Product', on_delete=models.PROTECT)
    variant = models.ForeignKey('store.ProductVariant', on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField('تعداد', default=1)
    price = models.DecimalField('قیمت واحد', max_digits=12, decimal_places=0)
    discount_percent = models.PositiveIntegerField('درصد تخفیف', default=0)

    class Meta:
        verbose_name = 'آیتم سفارش'
        verbose_name_plural = 'آیتم‌های سفارش'

    def __str__(self):
        return f"{self.order.order_number} - {self.product.name}"

    @property
    def final_price(self):
        if self.discount_percent:
            return int(self.price * (1 - self.discount_percent / 100))
        return self.price

    @property
    def total_price(self):
        return self.final_price * self.quantity


class Payment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار'),
        ('success', 'موفق'),
        ('failed', 'ناموفق'),
        ('refunded', 'مسترد'),
    ]
    order = models.ForeignKey(Order, on_delete=models.PROTECT, related_name='payments')
    amount = models.DecimalField('مبلغ', max_digits=12, decimal_places=0)
    gateway = models.CharField('درگاه', max_length=50, default='zarinpal')
    authority = models.CharField('کد مرجع', max_length=100, blank=True)
    ref_id = models.CharField('شناسه پرداخت', max_length=100, blank=True)
    status = models.CharField('وضعیت', max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'پرداخت'
        verbose_name_plural = 'پرداخت‌ها'

    def __str__(self):
        return f"{self.order.order_number} - {self.amount}"


class ReturnRequest(models.Model):
    REASON_CHOICES = [
        ('wrong_size', 'سایز اشتباه'),
        ('wrong_item', 'کالای اشتباه'),
        ('defective', 'معیوب'),
        ('not_as_described', 'مطابق توضیحات نیست'),
        ('changed_mind', 'پشیمانی'),
        ('damaged', 'آسیب دیده'),
    ]
    STATUS_CHOICES = [
        ('pending', 'در انتظار بررسی'),
        ('approved', 'تایید شده'),
        ('rejected', 'رد شده'),
        ('processing', 'در حال پردازش'),
        ('completed', 'تکمیل شده'),
    ]
    order_item = models.ForeignKey(OrderItem, on_delete=models.PROTECT, related_name='returns')
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    reason = models.CharField('دلیل', max_length=30, choices=REASON_CHOICES)
    description = models.TextField('توضیحات', blank=True)
    images = models.ManyToManyField('ReturnImage', blank=True)
    status = models.CharField('وضعیت', max_length=15, choices=STATUS_CHOICES, default='pending')
    admin_note = models.TextField('یادداشت مدیر', blank=True)
    refund_amount = models.DecimalField('مبلغ بازگشتی', max_digits=12, decimal_places=0, null=True, blank=True)
    tracking_code = models.CharField('کد رهگیری بازگشت', max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'درخواست مرجوعی'
        verbose_name_plural = 'درخواست‌های مرجوعی'

    def __str__(self):
        return f"مرجوعی {self.order_item.order.order_number}"


class ReturnImage(models.Model):
    image = models.ImageField('تصویر', upload_to='returns/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
