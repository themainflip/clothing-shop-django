from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from apps.cart.cart import Cart
from .models import Order, OrderItem, Payment, Coupon, ReturnRequest, ReturnImage
from apps.accounts.models import Address
import uuid


@login_required
def checkout(request):
    cart = Cart(request)
    if len(cart) == 0:
        messages.error(request, 'سبد خرید شما خالی است.')
        return redirect('cart:detail')
    
    addresses = request.user.addresses.all()
    
    if request.method == 'POST':
        # Get form data
        address_id = request.POST.get('address_id')
        shipping_method = request.POST.get('shipping_method', 'standard')
        payment_method = request.POST.get('payment_method', 'online')
        coupon_code = request.POST.get('coupon_code', '')
        is_gift = request.POST.get('is_gift', False)
        gift_message = request.POST.get('gift_message', '')
        has_insurance = request.POST.get('has_insurance', False)
        
        # Get address
        if address_id:
            address = get_object_or_404(Address, id=address_id, user=request.user)
        else:
            messages.error(request, 'لطفاً آدرس تحویل را انتخاب کنید.')
            return render(request, 'orders/checkout.html', {'cart': cart, 'addresses': addresses})
        
        # Calculate costs
        subtotal = cart.total_price
        shipping_cost = cart.shipping_cost
        discount_amount = 0
        
        # Coupon
        coupon = None
        if coupon_code:
            try:
                coupon = Coupon.objects.get(
                    code=coupon_code, is_active=True,
                    valid_from__lte=timezone.now(),
                    valid_to__gte=timezone.now()
                )
                discount_amount = coupon.calculate_discount(subtotal)
            except Coupon.DoesNotExist:
                messages.warning(request, 'کد تخفیف معتبر نیست.')
        
        # Loyalty points
        loyalty_points_used = 0
        loyalty_discount = 0
        use_points = request.POST.get('use_points')
        if use_points and request.user.loyalty_points > 0:
            from django.conf import settings
            max_points = min(request.user.loyalty_points, 1000)  # max 1000 points per order
            loyalty_discount = max_points * getattr(settings, 'POINTS_VALUE', 100)
            loyalty_points_used = max_points
        
        # Wallet
        wallet_used = 0
        use_wallet = request.POST.get('use_wallet')
        if use_wallet and request.user.wallet_balance > 0:
            wallet_used = min(float(request.user.wallet_balance), float(subtotal))
        
        total = subtotal + shipping_cost - discount_amount - loyalty_discount - wallet_used
        
        # Create order
        order = Order.objects.create(
            user=request.user,
            shipping_address=f"{address.province} - {address.city} - {address.address}",
            receiver_name=address.receiver_name,
            receiver_phone=address.receiver_phone,
            subtotal=subtotal,
            shipping_cost=shipping_cost,
            discount_amount=discount_amount,
            total=max(0, total),
            coupon=coupon,
            loyalty_points_used=loyalty_points_used,
            wallet_amount_used=wallet_used,
            shipping_method=shipping_method,
            payment_method=payment_method,
            is_gift=bool(is_gift),
            gift_message=gift_message,
            has_insurance=bool(has_insurance),
        )
        
        # Create order items
        for item in cart:
            OrderItem.objects.create(
                order=order,
                product=item['variant'].product,
                variant=item['variant'],
                quantity=item['quantity'],
                price=item['price'],
                discount_percent=item['variant'].product.discount_percent,
            )
            # Reduce stock
            item['variant'].stock -= item['quantity']
            item['variant'].save()
        
        # Deduct loyalty points and wallet
        if loyalty_points_used:
            request.user.loyalty_points -= loyalty_points_used
            request.user.save()
        if wallet_used:
            request.user.wallet_balance -= wallet_used
            request.user.save()
        
        # Clear cart
        cart.clear()
        
        if payment_method == 'online':
            return redirect('orders:payment', order_id=order.id)
        else:
            return redirect('orders:order_confirm', order_id=order.id)
    
    context = {
        'cart': cart,
        'addresses': addresses,
    }
    return render(request, 'orders/checkout.html', context)


@login_required
def payment(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    
    if request.method == 'POST':
        # Simulate payment - in production connect to ZarinPal
        payment_obj = Payment.objects.create(
            order=order,
            amount=order.total,
            gateway='zarinpal',
            status='success',
            ref_id=f"REF{uuid.uuid4().hex[:10].upper()}"
        )
        order.status = 'paid'
        order.save()
        
        # Add loyalty points
        from django.conf import settings
        points = int(order.total / 1000 * getattr(settings, 'POINTS_PER_PURCHASE', 10))
        request.user.loyalty_points += points
        request.user.save()
        
        return redirect('orders:order_confirm', order_id=order.id)
    
    return render(request, 'orders/payment.html', {'order': order})


@login_required
def order_confirm(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'orders/order_confirm.html', {'order': order})


@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'orders/order_list.html', {'orders': orders})


@login_required
def order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'orders/order_detail.html', {'order': order})


@login_required
def return_request(request, order_item_id):
    order_item = get_object_or_404(OrderItem, id=order_item_id, order__user=request.user)
    
    if request.method == 'POST':
        return_obj = ReturnRequest.objects.create(
            order_item=order_item,
            user=request.user,
            reason=request.POST['reason'],
            description=request.POST.get('description', ''),
        )
        for image_file in request.FILES.getlist('images'):
            img = ReturnImage.objects.create(image=image_file)
            return_obj.images.add(img)
        
        messages.success(request, 'درخواست مرجوعی شما ثبت شد.')
        return redirect('orders:order_detail', order_id=order_item.order.id)
    
    return render(request, 'orders/return_request.html', {
        'order_item': order_item,
        'reason_choices': ReturnRequest.REASON_CHOICES,
    })


@login_required
def apply_coupon(request):
    if request.method == 'POST':
        code = request.POST.get('code', '').strip().upper()
        cart = Cart(request)
        
        try:
            coupon = Coupon.objects.get(
                code=code, is_active=True,
                valid_from__lte=timezone.now(),
                valid_to__gte=timezone.now()
            )
            discount = coupon.calculate_discount(cart.total_price)
            return JsonResponse({
                'valid': True,
                'discount': int(discount),
                'message': f'کد تخفیف اعمال شد. {int(discount):,} تومان تخفیف'
            })
        except Coupon.DoesNotExist:
            return JsonResponse({'valid': False, 'message': 'کد تخفیف معتبر نیست.'})
    
    return JsonResponse({'valid': False, 'message': 'درخواست نامعتبر.'})
