from django.contrib import admin
from .models import (Category, Brand, Color, Size, Product, ProductImage,
                     ProductVariant, Review, Question, Wishlist, PriceHistory, StockNotification)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'parent', 'gender', 'is_active', 'order']
    list_filter = ['gender', 'is_active']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}
    list_editable = ['is_active', 'order']


@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ['name', 'is_featured', 'is_active']
    list_editable = ['is_featured', 'is_active']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Color)
class ColorAdmin(admin.ModelAdmin):
    list_display = ['name', 'hex_code']


@admin.register(Size)
class SizeAdmin(admin.ModelAdmin):
    list_display = ['name', 'size_type', 'order']
    list_editable = ['order']


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


class ProductVariantInline(admin.TabularInline):
    model = ProductVariant
    extra = 1


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'brand', 'price', 'discount_percent',
                    'is_active', 'is_featured', 'is_new', 'sold_count', 'view_count']
    list_filter = ['category', 'brand', 'fabric', 'season', 'occasion', 'is_active', 'is_featured']
    search_fields = ['name', 'sku']
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ProductImageInline, ProductVariantInline]
    list_editable = ['is_active', 'is_featured', 'discount_percent']
    readonly_fields = ['view_count', 'sold_count', 'created_at']
    fieldsets = (
        ('اطلاعات اصلی', {'fields': ('name', 'slug', 'sku', 'category', 'brand', 'vendor', 'description')}),
        ('مشخصات', {'fields': ('fabric', 'washing_instructions', 'neck_type', 'sleeve_type', 'season', 'occasion', 'is_domestic')}),
        ('قیمت', {'fields': ('price', 'discount_percent')}),
        ('مدل', {'fields': ('model_height', 'model_size')}),
        ('وضعیت', {'fields': ('is_active', 'is_featured', 'is_new')}),
        ('آمار', {'fields': ('view_count', 'sold_count', 'created_at')}),
    )


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['product', 'user', 'rating', 'is_approved', 'is_verified_purchase', 'created_at']
    list_filter = ['rating', 'is_approved', 'is_verified_purchase']
    list_editable = ['is_approved']


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['product', 'user', 'is_public', 'created_at']
    list_editable = ['is_public']
