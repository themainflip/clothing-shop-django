from .models import Category


def categories_context(request):
    return {
        'main_categories': Category.objects.filter(parent=None, is_active=True).prefetch_related('children')
    }
