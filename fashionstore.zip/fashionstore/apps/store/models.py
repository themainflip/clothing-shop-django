from django.db import models
from django.utils.text import slugify
from django.contrib.auth import get_user_model
from django.utils import timezone
import uuid

User = get_user_model()


class Category(models.Model):
    GENDER_CHOICES = [
        ('women', 'زنانه'),
        ('men', 'مردانه'),
        ('unisex', 'یونی‌سکس'),
        ('kids', 'بچگانه'),
    ]
    name = models.CharField('نام دسته‌بندی', max_length=200)
    slug = models.SlugField(unique=True, allow_unicode=True)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE,
                                related_name='children', verbose_name='دسته‌بندی والد')
    gender = models.CharField('جنسیت', max_length=10, choices=GENDER_CHOICES, blank=True)
    image = models.ImageField('تصویر', upload_to='categories/', blank=True)
    description = models.TextField('توضیحات', blank=True)
    is_active = models.BooleanField('فعال', default=True)
    order = models.PositiveIntegerField('ترتیب', default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'دسته‌بندی'
        verbose_name_plural = 'دسته‌بندی‌ها'
        ordering = ['order', 'name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)


class Brand(models.Model):
    name = models.CharField('نام برند', max_length=200)
    slug = models.SlugField(unique=True, allow_unicode=True)
    logo = models.ImageField('لوگو', upload_to='brands/', blank=True)
    description = models.TextField('توضیحات', blank=True)
    website = models.URLField('وب‌سایت', blank=True)
    is_featured = models.BooleanField('ویژه', default=False)
    is_active = models.BooleanField('فعال', default=True)

    class Meta:
        verbose_name = 'برند'
        verbose_name_plural = 'برندها'

    def __str__(self):
        return self.name


class Color(models.Model):
    name = models.CharField('نام رنگ', max_length=100)
    hex_code = models.CharField('کد رنگ', max_length=7)  # e.g. #FF5733

    class Meta:
        verbose_name = 'رنگ'
        verbose_name_plural = 'رنگ‌ها'

    def __str__(self):
        return self.name


class Size(models.Model):
    SIZE_TYPE_CHOICES = [
        ('clothing', 'لباس'),
        ('shoe', 'کفش'),
        ('accessory', 'اکسسوری'),
    ]
    name = models.CharField('سایز', max_length=20)
    size_type = models.CharField('نوع', max_length=20, choices=SIZE_TYPE_CHOICES, default='clothing')
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'سایز'
        verbose_name_plural = 'سایزها'
        ordering = ['order', 'name']

    def __str__(self):
        return self.name


class Product(models.Model):
    FABRIC_CHOICES = [
        ('cotton', 'پنبه'),
        ('polyester', 'پلی‌استر'),
        ('wool', 'پشم'),
        ('silk', 'ابریشم'),
        ('linen', 'کتان'),
        ('denim', 'دنیم'),
        ('leather', 'چرم'),
        ('synthetic', 'مصنوعی'),
        ('mixed', 'مخلوط'),
    ]
    NECK_TYPE_CHOICES = [
        ('round', 'گرد'),
        ('v_neck', 'هفت'),
        ('polo', 'پولو'),
        ('collar', 'یقه‌دار'),
        ('turtleneck', 'یقه اسکی'),
        ('hood', 'هودی'),
    ]
    SLEEVE_TYPE_CHOICES = [
        ('short', 'آستین کوتاه'),
        ('long', 'آستین بلند'),
        ('sleeveless', 'بی‌آستین'),
        ('3_4', 'سه‌چهارم'),
    ]
    SEASON_CHOICES = [
        ('spring', 'بهار'),
        ('summer', 'تابستان'),
        ('autumn', 'پاییز'),
        ('winter', 'زمستان'),
        ('all', 'چهار فصل'),
    ]
    OCCASION_CHOICES = [
        ('casual', 'راحتی'),
        ('formal', 'رسمی'),
        ('sport', 'ورزشی'),
        ('party', 'مجلسی'),
        ('work', 'کار'),
        ('beach', 'ساحل'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField('نام محصول', max_length=300)
    slug = models.SlugField(unique=True, allow_unicode=True, max_length=300)
    sku = models.CharField('کد محصول', max_length=50, unique=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT,
                                  related_name='products', verbose_name='دسته‌بندی')
    brand = models.ForeignKey(Brand, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name='products', verbose_name='برند')
    vendor = models.ForeignKey('vendors.Vendor', on_delete=models.SET_NULL, null=True, blank=True,
                                related_name='products', verbose_name='فروشنده')
    description = models.TextField('توضیحات')
    fabric = models.CharField('جنس پارچه', max_length=20, choices=FABRIC_CHOICES, blank=True)
    washing_instructions = models.TextField('نحوه شستشو', blank=True)
    neck_type = models.CharField('نوع یقه', max_length=20, choices=NECK_TYPE_CHOICES, blank=True)
    sleeve_type = models.CharField('نوع آستین', max_length=20, choices=SLEEVE_TYPE_CHOICES, blank=True)
    season = models.CharField('فصل', max_length=10, choices=SEASON_CHOICES, blank=True)
    occasion = models.CharField('مناسبت', max_length=20, choices=OCCASION_CHOICES, blank=True)
    is_domestic = models.BooleanField('تولید داخل', default=True)
    is_featured = models.BooleanField('ویژه', default=False)
    is_new = models.BooleanField('جدید', default=True)
    is_active = models.BooleanField('فعال', default=True)

    # Pricing
    price = models.DecimalField('قیمت', max_digits=12, decimal_places=0)
    discount_percent = models.PositiveIntegerField('درصد تخفیف', default=0)

    # Model info
    model_height = models.PositiveIntegerField('قد مدل (سانتی‌متر)', null=True, blank=True)
    model_size = models.ForeignKey(Size, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='+', verbose_name='سایز مدل')

    # Stats
    view_count = models.PositiveIntegerField('تعداد بازدید', default=0)
    sold_count = models.PositiveIntegerField('تعداد فروش', default=0)

    created_at = models.DateTimeField('تاریخ ایجاد', auto_now_add=True)
    updated_at = models.DateTimeField('آخرین ویرایش', auto_now=True)

    class Meta:
        verbose_name = 'محصول'
        verbose_name_plural = 'محصولات'
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)

    @property
    def final_price(self):
        if self.discount_percent:
            return int(self.price * (1 - self.discount_percent / 100))
        return self.price

    @property
    def is_on_sale(self):
        return self.discount_percent > 0

    @property
    def main_image(self):
        return self.images.filter(is_main=True).first() or self.images.first()

    @property
    def average_rating(self):
        reviews = self.reviews.all()
        if reviews:
            return sum(r.rating for r in reviews) / len(reviews)
        return 0

    @property
    def total_stock(self):
        return sum(v.stock for v in self.variants.all())


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField('تصویر', upload_to='products/')
    alt_text = models.CharField('متن جایگزین', max_length=200, blank=True)
    is_main = models.BooleanField('تصویر اصلی', default=False)
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'تصویر محصول'
        verbose_name_plural = 'تصاویر محصول'
        ordering = ['order']

    def __str__(self):
        return f"{self.product.name} - تصویر {self.order}"


class ProductVariant(models.Model):
    """ترکیب سایز و رنگ با موجودی"""
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='variants')
    size = models.ForeignKey(Size, on_delete=models.PROTECT, verbose_name='سایز')
    color = models.ForeignKey(Color, on_delete=models.PROTECT, verbose_name='رنگ')
    stock = models.PositiveIntegerField('موجودی', default=0)
    additional_price = models.DecimalField('قیمت اضافه', max_digits=10, decimal_places=0, default=0)

    class Meta:
        verbose_name = 'تنوع محصول'
        verbose_name_plural = 'تنوع‌های محصول'
        unique_together = ['product', 'size', 'color']

    def __str__(self):
        return f"{self.product.name} - {self.size} - {self.color}"

    @property
    def is_available(self):
        return self.stock > 0


class StockNotification(models.Model):
    """اطلاع‌رسانی موجود شدن محصول"""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    variant = models.ForeignKey(ProductVariant, on_delete=models.CASCADE)
    email = models.EmailField()
    created_at = models.DateTimeField(auto_now_add=True)
    notified = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'اطلاع‌رسانی موجودی'
        verbose_name_plural = 'اطلاع‌رسانی‌های موجودی'
        unique_together = ['user', 'variant']


class Review(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField('امتیاز', choices=[(i, i) for i in range(1, 6)])
    title = models.CharField('عنوان', max_length=200, blank=True)
    body = models.TextField('متن نظر')
    size_feedback = models.CharField('بازخورد سایز', max_length=20,
                                      choices=[('small', 'کوچک'), ('true', 'درست'), ('large', 'بزرگ')],
                                      blank=True)
    is_verified_purchase = models.BooleanField('خرید تایید‌شده', default=False)
    is_approved = models.BooleanField('تایید‌شده', default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'نظر'
        verbose_name_plural = 'نظرات'
        unique_together = ['product', 'user']

    def __str__(self):
        return f"{self.user} - {self.product.name} - {self.rating}★"


class Question(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='questions')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.TextField('سوال')
    answer = models.TextField('پاسخ', blank=True)
    answered_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                     related_name='answered_questions')
    created_at = models.DateTimeField(auto_now_add=True)
    is_public = models.BooleanField('عمومی', default=True)

    class Meta:
        verbose_name = 'سوال'
        verbose_name_plural = 'سوالات'

    def __str__(self):
        return f"{self.user} - {self.product.name}"


class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'علاقه‌مندی'
        verbose_name_plural = 'علاقه‌مندی‌ها'
        unique_together = ['user', 'product']


class PriceHistory(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='price_history')
    price = models.DecimalField('قیمت', max_digits=12, decimal_places=0)
    discount_percent = models.PositiveIntegerField('درصد تخفیف', default=0)
    recorded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'تاریخچه قیمت'
        verbose_name_plural = 'تاریخچه قیمت‌ها'
        ordering = ['-recorded_at']
