from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q, Avg, Count
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib import messages
from .models import Product, Category, Brand, Review, Wishlist, Question, StockNotification


def home(request):
    featured_products = Product.objects.filter(is_featured=True, is_active=True)[:8]
    new_arrivals = Product.objects.filter(is_new=True, is_active=True).order_by('-created_at')[:8]
    on_sale = Product.objects.filter(discount_percent__gt=0, is_active=True).order_by('-discount_percent')[:8]
    top_categories = Category.objects.filter(parent=None, is_active=True)[:8]
    
    context = {
        'featured_products': featured_products,
        'new_arrivals': new_arrivals,
        'on_sale': on_sale,
        'top_categories': top_categories,
    }
    return render(request, 'store/home.html', context)


def product_list(request):
    products = Product.objects.filter(is_active=True).select_related('brand', 'category')
    
    # Filters
    category_slug = request.GET.get('category')
    brand_id = request.GET.get('brand')
    color_ids = request.GET.getlist('color')
    size_ids = request.GET.getlist('size')
    fabric = request.GET.get('fabric')
    neck_type = request.GET.get('neck')
    sleeve_type = request.GET.get('sleeve')
    season = request.GET.get('season')
    occasion = request.GET.get('occasion')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    on_sale = request.GET.get('on_sale')
    in_stock = request.GET.get('in_stock')
    is_domestic = request.GET.get('domestic')
    gender = request.GET.get('gender')
    sort = request.GET.get('sort', '-created_at')
    q = request.GET.get('q')

    if q:
        products = products.filter(
            Q(name__icontains=q) | Q(description__icontains=q) | Q(brand__name__icontains=q)
        )
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(
            Q(category=category) | Q(category__parent=category)
        )
    if brand_id:
        products = products.filter(brand_id=brand_id)
    if color_ids:
        products = products.filter(variants__color_id__in=color_ids).distinct()
    if size_ids:
        products = products.filter(variants__size_id__in=size_ids).distinct()
    if fabric:
        products = products.filter(fabric=fabric)
    if neck_type:
        products = products.filter(neck_type=neck_type)
    if sleeve_type:
        products = products.filter(sleeve_type=sleeve_type)
    if season:
        products = products.filter(season=season)
    if occasion:
        products = products.filter(occasion=occasion)
    if min_price:
        products = products.filter(price__gte=min_price)
    if max_price:
        products = products.filter(price__lte=max_price)
    if on_sale:
        products = products.filter(discount_percent__gt=0)
    if in_stock:
        products = products.filter(variants__stock__gt=0).distinct()
    if is_domestic:
        products = products.filter(is_domestic=True)
    if gender:
        products = products.filter(category__gender=gender)

    # Sorting
    sort_map = {
        'price_asc': 'price',
        'price_desc': '-price',
        '-created_at': '-created_at',
        'bestseller': '-sold_count',
        'discount': '-discount_percent',
        'rating': '-reviews__rating',
    }
    products = products.order_by(sort_map.get(sort, '-created_at'))

    # Pagination
    paginator = Paginator(products, 24)
    page = request.GET.get('page')
    page_obj = paginator.get_page(page)

    context = {
        'page_obj': page_obj,
        'total_count': paginator.count,
        'sort': sort,
        'brands': Brand.objects.filter(is_active=True),
        'categories': Category.objects.filter(parent=None, is_active=True),
        'fabric_choices': Product.FABRIC_CHOICES,
        'season_choices': Product.SEASON_CHOICES,
        'occasion_choices': Product.OCCASION_CHOICES,
        'current_filters': request.GET,
    }
    return render(request, 'store/product_list.html', context)


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    
    # Increment view count
    Product.objects.filter(pk=product.pk).update(view_count=product.view_count + 1)
    
    # Related products
    related = Product.objects.filter(
        category=product.category, is_active=True
    ).exclude(pk=product.pk)[:8]
    
    # Complementary products (same occasion)
    complementary = Product.objects.filter(
        occasion=product.occasion, is_active=True
    ).exclude(pk=product.pk).exclude(category=product.category)[:4]
    
    # Reviews
    reviews = product.reviews.filter(is_approved=True).order_by('-created_at')
    questions = product.questions.filter(is_public=True)
    
    # User-specific
    user_wishlist = []
    user_review = None
    if request.user.is_authenticated:
        user_wishlist = Wishlist.objects.filter(user=request.user).values_list('product_id', flat=True)
        user_review = Review.objects.filter(product=product, user=request.user).first()
    
    # Size guide
    variants_by_color = {}
    for variant in product.variants.all():
        color_name = variant.color.name
        if color_name not in variants_by_color:
            variants_by_color[color_name] = []
        variants_by_color[color_name].append(variant)

    context = {
        'product': product,
        'related': related,
        'complementary': complementary,
        'reviews': reviews,
        'questions': questions,
        'user_wishlist': user_wishlist,
        'user_review': user_review,
        'variants_by_color': variants_by_color,
    }
    return render(request, 'store/product_detail.html', context)


@login_required
@require_POST
def toggle_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    wishlist_item, created = Wishlist.objects.get_or_create(
        user=request.user, product=product
    )
    if not created:
        wishlist_item.delete()
        in_wishlist = False
    else:
        in_wishlist = True
    return JsonResponse({'in_wishlist': in_wishlist})


@login_required
def wishlist(request):
    items = Wishlist.objects.filter(user=request.user).select_related('product')
    return render(request, 'store/wishlist.html', {'items': items})


@login_required
@require_POST
def add_review(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    
    # Check if user has bought this product
    from apps.orders.models import OrderItem
    has_purchased = OrderItem.objects.filter(
        order__user=request.user,
        product=product,
        order__status='delivered'
    ).exists()
    
    rating = int(request.POST.get('rating', 5))
    title = request.POST.get('title', '')
    body = request.POST.get('body', '')
    size_feedback = request.POST.get('size_feedback', '')
    
    review, created = Review.objects.update_or_create(
        product=product, user=request.user,
        defaults={
            'rating': rating,
            'title': title,
            'body': body,
            'size_feedback': size_feedback,
            'is_verified_purchase': has_purchased,
        }
    )
    messages.success(request, 'نظر شما ثبت شد و پس از تایید نمایش داده می‌شود.')
    return redirect('store:product_detail', slug=product.slug)


@login_required
@require_POST
def ask_question(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    question_text = request.POST.get('question', '')
    if question_text:
        Question.objects.create(
            product=product,
            user=request.user,
            question=question_text,
        )
        messages.success(request, 'سوال شما ثبت شد.')
    return redirect('store:product_detail', slug=product.slug)


@login_required
@require_POST
def notify_stock(request, variant_id):
    from .models import ProductVariant
    variant = get_object_or_404(ProductVariant, id=variant_id)
    email = request.user.email
    StockNotification.objects.get_or_create(
        user=request.user,
        variant=variant,
        defaults={'email': email}
    )
    return JsonResponse({'success': True, 'message': 'اطلاع‌رسانی ثبت شد.'})


def search(request):
    q = request.GET.get('q', '')
    results = []
    suggestions = []
    
    if q:
        results = Product.objects.filter(
            Q(name__icontains=q) | Q(brand__name__icontains=q),
            is_active=True
        )[:20]
        
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        suggestions = [{'name': p.name, 'slug': p.slug} for p in results[:5]]
        return JsonResponse({'suggestions': suggestions})
    
    return render(request, 'store/search.html', {'results': results, 'q': q})


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug, is_active=True)
    return redirect(f'/products/?category={slug}')
