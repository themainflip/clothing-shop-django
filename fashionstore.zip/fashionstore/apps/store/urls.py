from django.urls import path
from . import views

app_name = 'store'

urlpatterns = [
    path('', views.home, name='home'),
    path('products/', views.product_list, name='product_list'),
    path('products/<slug:slug>/', views.product_detail, name='product_detail'),
    path('search/', views.search, name='search'),
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),
    path('wishlist/', views.wishlist, name='wishlist'),
    path('wishlist/toggle/<uuid:product_id>/', views.toggle_wishlist, name='toggle_wishlist'),
    path('review/<uuid:product_id>/', views.add_review, name='add_review'),
    path('question/<uuid:product_id>/', views.ask_question, name='ask_question'),
    path('notify-stock/<int:variant_id>/', views.notify_stock, name='notify_stock'),
]
