from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from .models import BlogPost, BlogTag


def post_list(request):
    posts = BlogPost.objects.filter(status='published').order_by('-published_at')
    paginator = Paginator(posts, 12)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'blog/post_list.html', {'page_obj': page_obj})


def post_detail(request, slug):
    post = get_object_or_404(BlogPost, slug=slug, status='published')
    BlogPost.objects.filter(pk=post.pk).update(view_count=post.view_count + 1)
    related = BlogPost.objects.filter(status='published').exclude(pk=post.pk)[:3]
    return render(request, 'blog/post_detail.html', {'post': post, 'related': related})
