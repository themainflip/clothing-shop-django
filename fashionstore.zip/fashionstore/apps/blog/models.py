from django.db import models
from django.utils.text import slugify
from django.contrib.auth import get_user_model

User = get_user_model()


class BlogPost(models.Model):
    STATUS_CHOICES = [('draft', 'پیش‌نویس'), ('published', 'منتشرشده')]
    
    title = models.CharField('عنوان', max_length=300)
    slug = models.SlugField(unique=True, allow_unicode=True, max_length=300)
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    cover_image = models.ImageField('تصویر شاخص', upload_to='blog/')
    excerpt = models.TextField('خلاصه')
    body = models.TextField('متن کامل')
    tags = models.ManyToManyField('BlogTag', blank=True)
    status = models.CharField('وضعیت', max_length=10, choices=STATUS_CHOICES, default='draft')
    is_featured = models.BooleanField('ویژه', default=False)
    view_count = models.PositiveIntegerField('بازدید', default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'مقاله'
        verbose_name_plural = 'مقالات'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)


class BlogTag(models.Model):
    name = models.CharField('نام', max_length=100)
    slug = models.SlugField(unique=True, allow_unicode=True)

    class Meta:
        verbose_name = 'برچسب'
        verbose_name_plural = 'برچسب‌ها'

    def __str__(self):
        return self.name
