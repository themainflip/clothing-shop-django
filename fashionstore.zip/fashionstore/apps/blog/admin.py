from django.contrib import admin
from .models import BlogPost, BlogTag


@admin.register(BlogPost)
class BlogPostAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'status', 'is_featured', 'view_count', 'created_at']
    list_filter = ['status', 'is_featured']
    prepopulated_fields = {'slug': ('title',)}
    list_editable = ['status', 'is_featured']


@admin.register(BlogTag)
class BlogTagAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug': ('name',)}
